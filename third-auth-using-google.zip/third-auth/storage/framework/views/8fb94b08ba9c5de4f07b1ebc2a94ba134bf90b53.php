<?php echo e($slot); ?>

<?php /**PATH C:\Users\samue\OneDrive\Dokumen\WebProg\third-auth\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>